# CSCI 485 Assignment-1  
**By Akshay Aralikatti**  
**Date: 05-06-2025**  

## Title: Recursive Feature Elimination with Linear Regression  

## 1. Introduction  
This report explores the application of Recursive Feature Elimination (RFE) with a Linear Regression model on the Diabetes dataset. The goal is to determine the most important features affecting diabetes progression and improve model interpretability.

## 2. Dataset Exploration  
The **Diabetes dataset** from `sklearn.datasets.load_diabetes()` consists of 10 features:
- Age, sex, BMI, blood pressure, and six blood sample-derived measures.
- The target variable represents a continuous measure of diabetes progression over one year.

The dataset was split into **80% training and 20% testing** for model evaluation.

## 3. Linear Regression Model  
A **Linear Regression** model was trained on the dataset to establish a baseline performance. The model's accuracy was evaluated using the **R² score**, which measures the proportion of variance explained by the independent variables.

![RFE_Score](RFE_Score.png)

## 4. Implementing Recursive Feature Elimination (RFE)  
- **Process:**
  - The model started with all **10 features** and iteratively eliminated the least significant feature in each step.
  - The R² score was recorded for each iteration to track performance changes.
  - The process continued until only one feature remained.

- **Results:**
  - A plot of **R² score vs. number of features** helped identify the optimal feature set.
  - The selected features provided the best trade-off between interpretability and predictive power.

![graph](R2_Vs_Features.png)


## 5. Analyzing Feature Importance  
The RFE process revealed the most critical features contributing to diabetes progression. The three most important features were:
1. **BMI** - A crucial factor in diabetes risk.
2. **Blood Pressure** - Strongly associated with metabolic health.
3. **Glucose-related metrics** - Indicators of blood sugar regulation.

## 6. Reflection  
- **Feature Selection with RFE:** RFE effectively ranks features and removes redundant ones, enhancing model performance and interpretability.
- **Comparison with LASSO:** RFE selects features iteratively, whereas LASSO applies L1 regularization to shrink coefficients, sometimes setting them to zero. LASSO is computationally faster but less intuitive in feature selection.
- **Dataset Insights:** The most relevant features highlight key health indicators influencing diabetes progression, making this approach useful for medical analysis.

## 7. Conclusion  
Recursive Feature Elimination (RFE) provides a systematic way to improve model efficiency by selecting the most relevant features. This assignment demonstrated the effectiveness of RFE in identifying important predictors while maintaining model accuracy.

## 8. References  
- Scikit-learn documentation: https://scikit-learn.org/stable/modules/generated/sklearn.feature_selection.RFE.html
- Diabetes dataset description: https://scikit-learn.org/stable/datasets/toy_dataset.html#diabetes-dataset

